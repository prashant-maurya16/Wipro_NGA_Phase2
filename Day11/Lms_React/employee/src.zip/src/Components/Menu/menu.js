import {Link} from 'react-router-dom'


const Menu = () =>{
    return(
        <div>
            <Link to="/employeeList">EmployeeList</Link>
            &nbsp; &nbsp; &nbsp; &nbsp;

            
             
    
        </div>
)}


export default Menu;